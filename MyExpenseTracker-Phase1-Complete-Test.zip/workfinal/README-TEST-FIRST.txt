MY EXPENSE TRACKER — CONSOLIDATED PHASE 1 BUILD

This is the single consolidated test package containing the improvements planned for Phase 1. It is a separate copy and does not modify your live GitHub Pages app.

INCLUDED IMPROVEMENTS
1. Category-wise monthly budgets for each expense category.
2. Spending progress, remaining amount, overspending amount, and 50%, 80%, and 100% threshold status.
3. Category budget vs actual spending report.
4. Recurring income and expense rules: weekly, monthly, and yearly schedules; first occurrence date; optional end date; pause, resume, and delete.
5. Automatic creation of due recurring transactions when the app is opened/unlocked.
6. Duplicate prevention using a stable recurring-rule/date key.
7. Next occurrence display skips dates that have already been generated, so a monthly rule advances to its next scheduled date.
8. Serialized encrypted writes and post-save verification to prevent overlapping saves from losing newer data.
9. Changing the app-lock credential preserves existing transactions, monthly budgets, category budgets, and recurring rules while re-encrypting them with the new credential.
10. Full encrypted backup waits for queued saves and includes the complete encrypted payload.
11. Existing monthly budget, reports, chart selection, app lock, AES-GCM encryption, currency, themes, PWA/offline files, and fixed bottom navigation are retained.

IMPORTANT SAFETY
- Keep your live app and existing backup untouched until this test build has passed your checks.
- Extract this ZIP into a NEW folder. Do not overwrite your original project.
- Test with dummy records first. The app stores data locally on each device; this package does not create cloud sync or shared accounts.
- Category budgets and recurring rules are stored inside the same AES-GCM encrypted payload as transactions.
- The app does not send push notifications. Due recurring entries are generated when the app is opened/unlocked.
- Forgotten-PIN recovery / Recovery Key is NOT included. Do not change or forget your existing credential without keeping it safe.
- A missing recurring rule cannot be reconstructed from its generated transaction alone. Recreate missing rules only in this test copy after preserving your backup.

INSTALL / TEST
1. Extract the ZIP into a new folder.
2. Open that folder in VS Code.
3. Run index.html through your local web server (for example, Live Server). Do not open the HTML directly as a file because Web Crypto and PWA behavior require a secure context such as localhost or HTTPS.
4. Use a test credential and dummy transactions.
5. Set category budgets on Home. Add expenses to test remaining amounts and threshold warnings. Check Reports for category budget vs actual spending.
6. In Activity, create a recurring rule dated today. Confirm one transaction is generated.
7. Reload and unlock. Confirm the rule remains visible and the same occurrence is not duplicated. Confirm the next occurrence date advances (for a monthly rule, typically to the same calendar day next month, with month-end dates adjusted to the last valid day).
8. Test weekly and yearly schedules, future start dates, optional end dates, pause/resume/delete.
9. Open Settings > Manage app lock, change the test credential, unlock with the new credential, and confirm recurring rules and category budgets remain present.
10. Download a full encrypted backup and verify it is saved. Test restore only with a separate dummy-data test copy.

TECHNICAL NOTES
- The service-worker cache has been bumped to v5 so this package does not intentionally reuse the earlier Phase 1 cache.
- Existing encrypted payloads that do not contain categoryBudgets or recurringRules remain readable; missing fields default to empty collections.
- The build has had JavaScript syntax and package-integrity checks. This is not a substitute for your browser testing on desktop and iPhone.
